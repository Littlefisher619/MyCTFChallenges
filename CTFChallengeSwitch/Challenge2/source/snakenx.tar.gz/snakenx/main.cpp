#include <iostream>
#include <switch.h>
#include <time.h> // To make spawn value more random
#include <cstring>

using namespace std;
bool gameOver;
//Changed the width an height to better match the Switch's screen size.
const int width = 77;
const int height = 41;
int x, y, fruitX, fruitY;
//
const char* flagformat = "\x16\x07\x10\x02?9";
const int flaglen = 32;
char flagalphabet[100];
char flagchar = '?';
char flag[100];
long int seed;
long int timestamp;
//
int tailX[100], tailY[100];
int nTail;
enum eDirecton { STOP = 0, LEFT = 1, RIGHT = 2, UP = 3, DOWN = 4};
eDirecton dir;
//
u32 VibrationDeviceHandles[2][2];
u32 target_device = 0;
HidVibrationValue VibrationValue;
HidVibrationValue VibrationValue_stop;
HidVibrationValue VibrationValues[2];
void Setup()
{
    memset(flag,0,sizeof(flag));
    memset(flagalphabet,0,sizeof(flagalphabet));
    for(int i=48, j=0; i<=122; ++i, ++j){
        flagalphabet[j] = i;
        if(i==57) i=96;
        if(i==122) flagalphabet[j+1] = 95;
    }
    flagchar = flagformat[0] xor 0x44;

    gameOver = false;
    dir = STOP;
    x = width / 2;
    y = height / 2;
    fruitX = rand() % width;
    fruitY = rand() % height;
    //score = 0;
}
void Draw()
{
    for (int i = 0; i < width+2; i++)
        printf("#");
    printf("\n");

    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            if (j == 0)
                printf("#");
            if (i == y && j == x)
                printf("\033[0;32mO\033[0m");//Make snake green
            else if (i == fruitY && j == fruitX)
                printf("\033[0;36m*\033[0m");
            else
            {
                bool print = false;
                for (int k = 0; k < nTail; k++)
                {
                    if (tailX[k] == j && tailY[k] == i)
                    {
                        printf("\033[0;32mo\033[0m");//Make snake green
                        print = true;
                    }
                }
                if (!print)
                    printf(" ");
            }

            if (j == width - 1)
                printf("#");
        }
        printf("\n");
    }

    for (int i = 0; i < width+2; i++)
        printf("#");
    printf("\n");
    //printf("(%i,%i) Flag: %s Seed: %ld Time: %ld\n",fruitX, fruitY, flag, seed, timestamp);
    printf("Play game to generate your flag :)\n");
}
void Input()
{
    //Scan input for switch buttons
    hidScanInput();
    u64 kDown = hidKeysDown(CONTROLLER_P1_AUTO);
    //Check if statements if key was pressed this frame
    //Can't use switch statement for input with libnx
    if (kDown)
    {

        if(kDown & KEY_PLUS)
        {
            gameOver = true;
        }
        if(kDown & KEY_DLEFT)
        {
            dir = LEFT;
        }
        if(kDown & KEY_DRIGHT)
        {
            dir = RIGHT;
        }
        if(kDown & KEY_DUP)
        {
            dir = UP;
        }
        if(kDown & KEY_DDOWN)
        {
            dir = DOWN;
        }
    }
}
void viberationinit(){

    hidInitializeVibrationDevices(VibrationDeviceHandles[0], 2, CONTROLLER_HANDHELD, TYPE_HANDHELD);
    hidInitializeVibrationDevices(VibrationDeviceHandles[1], 2, CONTROLLER_PLAYER_1, TYPE_JOYCON_PAIR);
    VibrationValue.amp_low   = 0.2f;
    VibrationValue.freq_low  = 10.0f;
    VibrationValue.amp_high  = 0.8f;
    VibrationValue.freq_high = 10.0f;

    memset(VibrationValues, 0, sizeof(VibrationValues));
    memset(&VibrationValue_stop, 0, sizeof(HidVibrationValue));
    // Switch like stop behavior with muted band channels and frequencies set to default.
    VibrationValue_stop.freq_low  = 160.0f;
    VibrationValue_stop.freq_high = 320.0f;

}
void viberate(){
    target_device = 0;
    if (!hidGetHandheldMode())
        target_device = 1;
    memcpy(&VibrationValues[0], &VibrationValue, sizeof(HidVibrationValue));
    memcpy(&VibrationValues[1], &VibrationValue, sizeof(HidVibrationValue));
    hidSendVibrationValues(VibrationDeviceHandles[target_device], VibrationValues, 2);
    svcSleepThread(100);
    memcpy(&VibrationValues[0], &VibrationValue_stop, sizeof(HidVibrationValue));
    memcpy(&VibrationValues[1], &VibrationValue_stop, sizeof(HidVibrationValue));
    hidSendVibrationValues(VibrationDeviceHandles[target_device], VibrationValues, 2);
    hidSendVibrationValues(VibrationDeviceHandles[1-target_device], VibrationValues, 2);
}
void Logic()
{
    int prevX = tailX[0];
    int prevY = tailY[0];
    int prev2X, prev2Y;
    tailX[0] = x;
    tailY[0] = y;
    for (int i = 1; i < nTail; i++)
    {
        prev2X = tailX[i];
        prev2Y = tailY[i];
        tailX[i] = prevX;
        tailY[i] = prevY;
        prevX = prev2X;
        prevY = prev2Y;
    }
    switch (dir)
    {
        case LEFT:
            x--;
            break;
        case RIGHT:
            x++;
            break;
        case UP:
            y--;
            break;
        case DOWN:
            y++;
            break;
        default:
            break;
    }
    //Changed the consequences for walking in to a wall to better suit the screen size of the switch
    //if (x > width || x < 0 || y > height || y < 0)
    //gameOver = true;
    if (x >= width) x = 0; else if (x < 0) x = width - 1;
    if (y >= height) y = 0; else if (y < 0) y = height - 1;

//    for (int i = 0; i < nTail; i++)
//        if (tailX[i] == x && tailY[i] == y)
//            gameOver = true;

    if (x == fruitX && y == fruitY)
    {
        viberate();
        seed = nTail*4 + dir - 1;

        srand(seed);
        timestamp = time(0);

        //score += 10;
        fruitX = rand() % width;
        fruitY = rand() % height;
        flag[nTail++] = flagchar;
        if(nTail < strlen(flagformat) - 1)
            flagchar = flagformat[nTail] xor 0x44;
        else if(nTail == flaglen - 1)
            flagchar = flagformat[strlen(flagformat) - 1] xor 0x44;
        else if(nTail == flaglen)
            gameOver = true;
        else flagchar = flagalphabet[rand() % strlen(flagalphabet)];


    }
}

//Reset code for switch
void Reset()
{
    gameOver = false;//New game so reset game over state
    fill_n(tailX, 100, 0); //Reset the tail length
    fill_n(tailY, 100, 0); //Reset the tail length
    nTail = 0; //Reset the tail length
    dir = STOP; //Reset the movement direction
}

int main()
{
    appletInitializeGamePlayRecording();//Enable video capture
    consoleInit(NULL); //Init the switch console
    viberationinit();
    Restart:
    Setup();
    while (!gameOver)
    {
        Draw();
        consoleUpdate(NULL); //Update the console output
        svcSleepThread(100); //This game speed is more managable on the switch
        Input();
        Logic();
    }
    //Output the score and the instructions to start again on death
    printf("Game over!\nDo you get your flag?");
    consoleUpdate(NULL);
    //Game over logic. Changed from the code written by NULLx76 because that boots the user back in to hb menu on the switch
    while(true)
    {
        hidScanInput();
        u64 kDown = hidKeysDown(CONTROLLER_P1_AUTO);
        //When plus is pressed reset the vars and go to the restart label
        if(kDown & KEY_PLUS)
        {
            Reset();
            goto Restart;
        }
        //When minus is pressed return zero and go back to the homebrew menu
        if(kDown & KEY_MINUS)
        {
            goto Exit;
        }
    }
    Exit:
    consoleExit(NULL);
    return 0;
}