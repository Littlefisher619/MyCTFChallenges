#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <switch.h>
const int width = 77;
const int height = 41;
const char* flagalphabet = "0123456789abcdefghijklmnopqrstuvwxyz_";
const char* flagformat="RCTF{}";
const int flaglen = 32;
void solve(){
    FILE *seeds = fopen("seeds.txt", "r"),
         *flag = fopen("flag.txt", "w");
    if(seeds==NULL || flag==NULL){
        puts("failed to open file");
        return;
    }

    int seed, x, y, flagchar;
    puts("======Solving...");
    for(int i=0;i<flaglen;i++){
        if(i!=0){
            fscanf(seeds,"%d",&seed);
            srand(seed);
            x = rand() % width, y = rand() % height;
            if(i < strlen(flagformat) - 1)
                flagchar = flagformat[i];
            else if(i == flaglen - 1)
                flagchar = flagformat[strlen(flagformat) - 1];
            else flagchar = flagalphabet[rand() % strlen(flagalphabet)];
        }else x=-1, y=-1, flagchar = flagformat[0];
        printf("[Seed=%d] (%d, %d) %c\n", seed, x, y, flagchar);
        fputc(flagchar, flag);
    }
    fclose(seeds);
    fclose(flag);

}
int main(int argc, char* argv[])
{

    consoleInit(NULL);


    puts("Press A to get flag.");
    while (appletMainLoop())
    {
        hidScanInput();

        u64 kDown = hidKeysDown(CONTROLLER_P1_AUTO);

        if (kDown & KEY_PLUS)
            break; 
        if (kDown & KEY_A)
            solve();

        consoleUpdate(NULL);
    }

    consoleExit(NULL);
    return 0;
}
